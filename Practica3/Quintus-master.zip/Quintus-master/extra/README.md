This directory contains additional files that either are part of the Quintus core or aren't quite ready for primetime as well as the API docs in source form.

Use at your own risk.

Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by ltibbits ( http://www.freesound.org/people/ltibbits/  )
You can find this pack online at: http://www.freesound.org/people/ltibbits/packs/890/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 16319__ltibbits__tom_16_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16319/
    * license: Sampling+
  * 16320__ltibbits__tom_16_tight_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16320/
    * license: Sampling+
  * 16321__ltibbits__tom_16_tight_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16321/
    * license: Sampling+
  * 16309__ltibbits__snare_6_tight_open_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16309/
    * license: Sampling+
  * 16312__ltibbits__tom_12_tight_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16312/
    * license: Sampling+
  * 16317__ltibbits__tom_13_tight_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16317/
    * license: Sampling+
  * 16316__ltibbits__tom_13_tight_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16316/
    * license: Sampling+
  * 16315__ltibbits__tom_13_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16315/
    * license: Sampling+
  * 16318__ltibbits__tom_16_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16318/
    * license: Sampling+
  * 16314__ltibbits__tom_13_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16314/
    * license: Sampling+
  * 16308__ltibbits__snare_6_tight_open_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16308/
    * license: Sampling+
  * 16304__ltibbits__snare_4_open_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16304/
    * license: Sampling+
  * 16311__ltibbits__tom_12_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16311/
    * license: Sampling+
  * 16307__ltibbits__snare_5_tight_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16307/
    * license: Sampling+
  * 16310__ltibbits__tom_12_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16310/
    * license: Sampling+
  * 16305__ltibbits__snare_4_open_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16305/
    * license: Sampling+
  * 16306__ltibbits__snare_5_tight_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16306/
    * license: Sampling+
  * 16313__ltibbits__tom_12_tight_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16313/
    * license: Sampling+
  * 16299__ltibbits__snare_1_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16299/
    * license: Sampling+
  * 16290__ltibbits__kick2_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16290/
    * license: Sampling+
  * 16301__ltibbits__snare_2_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16301/
    * license: Sampling+
  * 16298__ltibbits__snare_1_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16298/
    * license: Sampling+
  * 16300__ltibbits__snare_2_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16300/
    * license: Sampling+
  * 16292__ltibbits__rim1_snare.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16292/
    * license: Sampling+
  * 16289__ltibbits__kick_med_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16289/
    * license: Sampling+
  * 16294__ltibbits__rim3_tom_13.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16294/
    * license: Sampling+
  * 16296__ltibbits__sticks_high_pitch.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16296/
    * license: Sampling+
  * 16297__ltibbits__sticks_low_pitch.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16297/
    * license: Sampling+
  * 16293__ltibbits__rim2_tom_12.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16293/
    * license: Sampling+
  * 16303__ltibbits__snare_3_open_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16303/
    * license: Sampling+
  * 16295__ltibbits__rim4_tom_16.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16295/
    * license: Sampling+
  * 16302__ltibbits__snare_3_open_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16302/
    * license: Sampling+
  * 16291__ltibbits__kick2_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16291/
    * license: Sampling+
  * 16288__ltibbits__kick_low_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16288/
    * license: Sampling+
  * 16287__ltibbits__kick_high_vol.wav
    * url: http://www.freesound.org/people/ltibbits/sounds/16287/
    * license: Sampling+

